# Vùng Facebook AI Auto v2

Bộ mã nguồn triển khai nền tảng cho tự động hóa Facebook Page: backend chạy liên tục, Android app quản lý, Gemini tạo nội dung, Meta Graph API đăng bài văn bản/ảnh, hàng đợi lịch đăng, webhook bình luận, thống kê cơ bản, nhật ký và giới hạn ngân sách.

> **Lưu ý trung thực:** Đây là bản triển khai nền tảng có chức năng thực, không phải cam kết mọi tính năng Meta hoạt động ngay khi giải nén. Cần cấu hình API keys, Meta App/quyền được cấp, HTTPS và chạy kiểm thử với Page thử nghiệm. Tính năng Messenger, tạo ảnh AI, tìm ảnh có giấy phép, A/B testing tự động và tối ưu giờ đăng dựa trên lịch sử còn là tích hợp mở rộng được ghi rõ trong `docs/ROADMAP.md`.

## Kiến trúc
- `android/`: Android Kotlin + Jetpack Compose, quản lý backend, Gemini key, Pages, tạo nội dung và xem trạng thái.
- `backend/`: Node.js + TypeScript + Express, PostgreSQL, Redis/BullMQ, Gemini API, Meta Graph API.
- `.github/workflows/build.yml`: build APK debug và lưu artifact.
- `docker-compose.yml`: PostgreSQL, Redis, API và worker trong một máy chủ.

## Chạy backend
1. Sao chép `backend/.env.example` thành `backend/.env`, thay tất cả giá trị bí mật.
2. Chạy `docker compose up --build -d`.
3. Kiểm tra `GET /health`.
4. Tạo tài khoản admin bằng `ADMIN_API_TOKEN` (token bearer); app Android cần URL backend HTTPS và token.

## Cấu hình Gemini và Meta
- Gemini key được nhập trong app và gửi đến backend qua HTTPS; backend mã hóa khi lưu bằng `ENCRYPTION_KEY`.
- Thêm Page bằng `POST /api/pages` với `pageId`, `pageName`, `pageAccessToken`. Token chỉ nên được cấp các quyền cần thiết.
- Quyền Meta có thể cần `pages_show_list`, `pages_read_engagement`, `pages_manage_posts`, `pages_read_user_content`, `pages_manage_engagement`, `read_insights` và quyền Messenger phù hợp. Quyền cụ thể phụ thuộc endpoint, loại ứng dụng và App Review của Meta.
- Không commit `.env`, token hoặc API key vào GitHub.

## Các API chính
- `GET /health`
- `GET/POST /api/settings/gemini`
- `GET/POST /api/pages`, `POST /api/pages/:id/test`
- `POST /api/ai/generate`
- `POST /api/posts` (tạo draft/lên lịch), `GET /api/posts`, `POST /api/posts/:id/publish`
- `GET /api/jobs`, `GET /api/logs`, `GET /api/insights/:pageId`
- `POST /api/budget`, `GET /api/budget`
- `POST /webhooks/meta` và `GET /webhooks/meta` để xác minh webhook

## An toàn vận hành
- Dùng HTTPS, token admin mạnh, database/Redis không public ra Internet.
- Chạy thử với một Page và nội dung ít rủi ro trước khi bật tự động.
- Tác vụ đăng có khóa idempotency ở DB để hạn chế đăng trùng; không thể đảm bảo exactly-once nếu Meta đã nhận bài nhưng phản hồi bị mất. Cần đối soát thủ công khi trạng thái `unknown`.
- Tự động trả lời chỉ bật sau khi đăng ký webhook và được cấp quyền phù hợp; cấu hình trả lời mặc định thận trọng.

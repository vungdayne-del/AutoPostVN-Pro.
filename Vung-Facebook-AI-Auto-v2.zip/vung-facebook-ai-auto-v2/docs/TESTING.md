# Checklist kiểm thử trước khi dùng thật

1. `GET /health` trả 200 và `ok: true`.
2. Không có bearer token hoặc token sai phải trả 401.
3. Lưu Gemini key rồi gọi `/api/settings/gemini` chỉ hiện `configured`, không trả key.
4. Tạo Page thử nghiệm, gọi `/api/pages/:id/test`; xác nhận Page ID/tên và quyền token.
5. Tạo bài draft; kiểm tra fingerprint ngăn bài trùng.
6. Đăng một bài văn bản thử nghiệm; kiểm tra ID trên Meta và nhật ký.
7. Đăng một ảnh từ URL HTTPS công khai hợp lệ; kiểm tra quyền sử dụng và hiển thị.
8. Tắt mạng/đưa token sai để kiểm tra failed state, retries và cảnh báo.
9. Khởi động lại backend/worker và Redis; kiểm tra tác vụ chờ không mất.
10. Kiểm tra múi giờ và thời gian lên lịch trong môi trường có timezone thực tế.
11. Gửi webhook comment thử nghiệm; kiểm tra idempotency theo comment ID.
12. Build APK bằng GitHub Actions và cài trên thiết bị Android thật.
13. Kiểm tra backup/restore database và xoay token trước khi chạy production.

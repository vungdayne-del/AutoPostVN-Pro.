# Tình trạng tính năng và giới hạn

## Có mã triển khai trong v2
- Android app Compose với tab điều hướng, gọi backend thật, hiển thị phản hồi và trạng thái đang xử lý.
- Backend được bảo vệ bằng bearer admin token; mã hóa Gemini key và Page Access Token bằng AES-256-GCM.
- PostgreSQL migrations cho Pages, posts, logs, AI usage, comments và reports.
- Tạo nội dung văn bản bằng Gemini.
- Thêm nhiều Facebook Page, kiểm tra Page token qua Graph API.
- Lên lịch và đưa tác vụ vào BullMQ; worker đăng bài text hoặc ảnh từ URL qua Graph API.
- Chống trùng theo fingerprint; nhật ký thành công/thất bại; retry queue.
- Webhook xác minh Meta và lưu event bình luận cơ bản.
- Endpoint trạng thái, nhật ký, tổng hợp báo cáo và theo dõi ngân sách ước tính.
- GitHub Actions build APK debug artifact.

## Cần hoàn thiện/tích hợp thêm trước khi gọi là sản phẩm production
- Tìm kiếm web thực: cần provider/search API được cấu hình; Gemini prompt hiện không tự bảo đảm truy cập web và chưa xác minh nguồn.
- Tạo ảnh AI: tích hợp API tạo ảnh riêng, tải ảnh lên object storage và lưu URL; hiện chỉ đăng ảnh nếu người dùng cung cấp URL công khai.
- OAuth Meta hoàn chỉnh, mã hóa refresh/rotation, phân quyền theo người dùng và quy trình App Review.
- Meta webhook signature verification (X-Hub-Signature-256), phân loại và trả lời bình luận thật; hiện chỉ ghi nhận comment webhook, chưa phản hồi tự động.
- Messenger inbox/API, permission-specific flows, templates và policy windows.
- Insights live từ Meta, biểu đồ, tối ưu giờ đăng theo dữ liệu từng Page.
- Báo cáo email/push, A/B testing tiêu đề, kiểm tra bản quyền ảnh, lọc nội dung nhạy cảm, chống spam nâng cao.
- Exactly-once publish không thể đảm bảo tuyệt đối với API từ xa; cần reconciliation nếu timeout sau khi Meta nhận bài.
- Bảo mật production: secret manager, rate limits, audit log, backup/restore, metrics/alerts, HTTPS reverse proxy, tests end-to-end.
- Định giá usage chính xác theo usage API thực tế; hiện `ai_usage` là ước tính placeholder.

## Meta permissions
Các quyền cụ thể thay đổi theo phiên bản Graph API, loại app, tài khoản và endpoint. Kiểm tra tài liệu Meta hiện hành và App Review trước khi bật: thường liên quan `pages_show_list`, `pages_read_engagement`, `pages_manage_posts`, `pages_read_user_content`, `pages_manage_engagement`, `read_insights`; Messenger có quyền riêng. Không được giả định quyền đã được cấp chỉ vì code gọi endpoint.

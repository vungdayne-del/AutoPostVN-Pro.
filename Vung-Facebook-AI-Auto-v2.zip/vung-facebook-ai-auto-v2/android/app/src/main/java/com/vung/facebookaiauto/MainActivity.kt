package com.vung.facebookaiauto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Facebook
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { VungApp() } }
}

private val http = OkHttpClient()
private val jsonType = "application/json; charset=utf-8".toMediaType()

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VungApp() {
    var tab by remember { mutableStateOf(0) }
    var baseUrl by remember { mutableStateOf("https://your-api.example.com") }
    var adminToken by remember { mutableStateOf("") }
    var geminiKey by remember { mutableStateOf("") }
    var pageId by remember { mutableStateOf("") }
    var pageName by remember { mutableStateOf("") }
    var pageToken by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var instructions by remember { mutableStateOf("Viết tự nhiên, có ích, không bịa dữ kiện.") }
    var result by remember { mutableStateOf("Nhập URL backend HTTPS và mã quản trị trong Cài đặt để bắt đầu.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    fun call(path: String, method: String = "GET", body: String? = null, done: (String) -> Unit) {
        if (baseUrl.startsWith("https://your-api" ) || adminToken.isBlank()) { result = "Hãy cấu hình URL backend HTTPS và mã quản trị trước."; return }
        busy = true
        scope.launch {
            val response = withContext(Dispatchers.IO) {
                try {
                    val builder = Request.Builder().url(baseUrl.trimEnd('/') + path).header("Authorization", "Bearer $adminToken")
                    if (body != null) builder.method(method, body.toRequestBody(jsonType))
                    val r = http.newCall(builder.build()).execute()
                    r.code.toString() + " " + (r.body?.string() ?: "")
                } catch (e: Exception) { "Lỗi kết nối: ${e.message}" }
            }
            busy = false; result = response; done(response)
        }
    }
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF1877F2), secondary = androidx.compose.ui.graphics.Color(0xFF00A884))) {
        Scaffold(topBar = { TopAppBar(title = { Column { Text("Vùng Facebook AI Auto"); Text("Điều khiển tự động hóa Fanpage", style = MaterialTheme.typography.labelSmall) } }) }, bottomBar = {
            NavigationBar { listOf("Tổng quan", "AI nội dung", "Fanpage", "Lịch sử", "Cài đặt").forEachIndexed { i, label -> NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { when(i) { 0 -> Icon(Icons.Default.Dashboard, null); 1 -> Icon(Icons.Default.AutoAwesome, null); 2 -> Icon(Icons.Default.Facebook, null); 3 -> Icon(Icons.Default.History, null); else -> Icon(Icons.Default.Settings, null) } }, label = { Text(label) }) } }
        }) { pad -> Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            when(tab) {
                0 -> { Text("Bảng điều khiển", style = MaterialTheme.typography.headlineSmall); Text("Các thao tác gọi API thật sẽ hiển thị mã HTTP và phản hồi backend."); Button(onClick = { call("/health") { } }, modifier = Modifier.fillMaxWidth()) { Text("Kiểm tra backend") }; Button(onClick = { call("/api/jobs") { } }, modifier = Modifier.fillMaxWidth()) { Text("Tải trạng thái hàng đợi") }; Button(onClick = { call("/api/reports/summary") { } }, modifier = Modifier.fillMaxWidth()) { Text("Báo cáo 7 ngày") } }
                1 -> { Text("AI tạo bài viết", style = MaterialTheme.typography.headlineSmall); OutlinedTextField(topic, { topic = it }, label = { Text("Chủ đề") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(instructions, { instructions = it }, label = { Text("Hướng dẫn AI") }, modifier = Modifier.fillMaxWidth(), minLines = 3); Button(onClick = { call("/api/ai/generate", "POST", "{\"topic\":${topic.quoteJson()},\"instructions\":${instructions.quoteJson()}}") { } }, enabled = !busy && topic.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Tạo nội dung bằng Gemini") }; Text("API key Gemini được lưu mã hóa trên backend qua thao tác ở Cài đặt.") }
                2 -> { Text("Quản lý Fanpage", style = MaterialTheme.typography.headlineSmall); OutlinedTextField(pageId, { pageId = it }, label = { Text("Facebook Page ID") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(pageName, { pageName = it }, label = { Text("Tên Page") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(pageToken, { pageToken = it }, label = { Text("Page Access Token") }, modifier = Modifier.fillMaxWidth()); Button(onClick = { call("/api/pages", "POST", "{\"pageId\":${pageId.quoteJson()},\"pageName\":${pageName.quoteJson()},\"pageAccessToken\":${pageToken.quoteJson()}}") { pageToken = "" } }, enabled = !busy && pageId.isNotBlank() && pageName.isNotBlank() && pageToken.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Lưu Fanpage") }; Button(onClick = { call("/api/pages") { } }, modifier = Modifier.fillMaxWidth()) { Text("Tải danh sách Fanpage") } }
                3 -> { Text("Lịch sử và nhật ký", style = MaterialTheme.typography.headlineSmall); Button(onClick = { call("/api/posts") { } }, modifier = Modifier.fillMaxWidth()) { Text("Tải bài viết") }; Button(onClick = { call("/api/logs?limit=50") { } }, modifier = Modifier.fillMaxWidth()) { Text("Tải nhật ký") } }
                else -> { Text("Cài đặt kết nối", style = MaterialTheme.typography.headlineSmall); OutlinedTextField(baseUrl, { baseUrl = it }, label = { Text("Backend URL (HTTPS)") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(adminToken, { adminToken = it }, label = { Text("Admin API token") }, modifier = Modifier.fillMaxWidth()); OutlinedTextField(geminiKey, { geminiKey = it }, label = { Text("Gemini API key") }, modifier = Modifier.fillMaxWidth()); Button(onClick = { call("/api/settings/gemini", "POST", "{\"apiKey\":${geminiKey.quoteJson()}}") { if (it.startsWith("200") || it.startsWith("201")) geminiKey = "" } }, enabled = !busy && geminiKey.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Lưu Gemini key an toàn") }; Button(onClick = { call("/health") { } }, modifier = Modifier.fillMaxWidth()) { Text("Kiểm tra kết nối") } }
            }
            HorizontalDivider(); Text("Phản hồi", style = MaterialTheme.typography.titleMedium); SelectionContainerText(result)
        } }
    }
}

@Composable private fun SelectionContainerText(value: String) { SelectionContainer { Text(value) } }
private fun String.quoteJson(): String = "\"" + replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r") + "\""

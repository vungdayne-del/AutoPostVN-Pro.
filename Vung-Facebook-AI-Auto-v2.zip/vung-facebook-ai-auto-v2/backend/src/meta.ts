import { decrypt } from './security.js';
import { pool, log } from './db.js';
const version = process.env.META_GRAPH_VERSION ?? 'v23.0';
export async function getPage(row:any) { return {...row, token:decrypt(row.token_enc)}; }
export async function testPage(row:any) { const p=await getPage(row); const r=await fetch(`https://graph.facebook.com/${version}/${encodeURIComponent(p.page_id)}?fields=id,name&access_token=${encodeURIComponent(p.token)}`); const j:any=await r.json(); if(!r.ok || j.error) throw new Error(j.error?.message ?? `Meta HTTP ${r.status}`); return j; }
export async function publishPost(postId:string) {
 const q=await pool.query(`SELECT p.*, pg.page_id AS meta_page_id, pg.token_enc FROM posts p JOIN pages pg ON pg.id=p.page_id WHERE p.id=$1`,[postId]);
 if(!q.rowCount) throw new Error('Không tìm thấy bài viết'); const p=q.rows[0];
 if(p.status==='published' && p.meta_post_id) return p.meta_post_id;
 await pool.query(`UPDATE posts SET status='publishing',error=NULL,updated_at=now() WHERE id=$1`,[postId]);
 try {
  const token=decrypt(p.token_enc); const endpoint=p.image_url ? `https://graph.facebook.com/${version}/${p.meta_page_id}/photos` : `https://graph.facebook.com/${version}/${p.meta_page_id}/feed`;
  const form=new URLSearchParams({access_token:token, message:[p.title,p.body].filter(Boolean).join('\n\n')}); if(p.image_url) form.set('url',p.image_url);
  const resp=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/x-www-form-urlencoded'},body:form}); const data:any=await resp.json();
  if(!resp.ok || data.error || !(data.id || data.post_id)) throw new Error(data.error?.message ?? `Meta HTTP ${resp.status}`);
  const metaId=data.post_id ?? data.id; await pool.query(`UPDATE posts SET status='published',meta_post_id=$2,updated_at=now() WHERE id=$1`,[postId,metaId]); await log('info','post_published',{metaId},postId); return metaId;
 } catch(e:any) { const message=String(e?.message ?? e); await pool.query(`UPDATE posts SET status='failed',error=$2,updated_at=now() WHERE id=$1`,[postId,message]); await log('error','post_publish_failed',{message},postId); throw e; }
}

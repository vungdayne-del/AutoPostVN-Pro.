import crypto from 'node:crypto';
const key = () => { const raw=process.env.ENCRYPTION_KEY ?? ''; if (!/^[a-fA-F0-9]{64}$/.test(raw)) throw new Error('ENCRYPTION_KEY phải là 64 ký tự hex (32 byte)'); return Buffer.from(raw,'hex'); };
export function encrypt(value:string) { const iv=crypto.randomBytes(12); const c=crypto.createCipheriv('aes-256-gcm',key(),iv); const data=Buffer.concat([c.update(value,'utf8'),c.final()]); return [iv.toString('hex'),c.getAuthTag().toString('hex'),data.toString('hex')].join(':'); }
export function decrypt(value:string) { const [iv,tag,data]=value.split(':'); const d=crypto.createDecipheriv('aes-256-gcm',key(),Buffer.from(iv,'hex')); d.setAuthTag(Buffer.from(tag,'hex')); return Buffer.concat([d.update(Buffer.from(data,'hex')),d.final()]).toString('utf8'); }

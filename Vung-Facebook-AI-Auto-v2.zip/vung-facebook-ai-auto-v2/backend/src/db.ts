import pg from 'pg';
import dotenv from 'dotenv';
dotenv.config();
export const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined });
export async function migrate() { const fs = await import('node:fs/promises'); const path = await import('node:path'); const sql = await fs.readFile(path.resolve('migrations/001_init.sql'), 'utf8'); await pool.query(sql); }
export async function log(level: string, event: string, details: unknown = {}, postId?: string) { await pool.query('INSERT INTO job_logs(level,event,details,post_id) VALUES($1,$2,$3,$4)', [level,event,JSON.stringify(details),postId ?? null]); }

import test from 'node:test';
import assert from 'node:assert/strict';
test('idempotency fingerprint is stable', async()=>{const crypto=await import('node:crypto');const f=(s:string)=>crypto.createHash('sha256').update(s).digest('hex');assert.equal(f('page|hello|body'),f('page|hello|body'));assert.notEqual(f('page|hello|body'),f('page|hello2|body'));});

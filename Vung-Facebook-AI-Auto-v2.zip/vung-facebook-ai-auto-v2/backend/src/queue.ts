import { Queue, Worker } from 'bullmq';
import IORedis from 'ioredis';
export const connection = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379', { maxRetriesPerRequest: null });
export const publishQueue = new Queue('publish-post', { connection });
export async function schedulePost(postId:string, when:Date) { const delay=Math.max(0, when.getTime()-Date.now()); await publishQueue.add('publish', {postId}, { delay, attempts: 5, backoff: {type:'exponential',delay:15000}, jobId:`publish-${postId}`, removeOnComplete:1000, removeOnFail:5000 }); }
export { Worker };

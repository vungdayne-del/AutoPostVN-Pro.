import 'dotenv/config';
import { Worker, connection } from './queue.js';
import { publishPost } from './meta.js';
import { log } from './db.js';
const worker=new Worker('publish-post',async job=>{await log('info','publish_job_started',{jobId:job.id},job.data.postId);return await publishPost(job.data.postId);},{connection,concurrency:3});
worker.on('failed',(job,err)=>{void log('error','publish_job_failed',{jobId:job?.id,message:err.message},job?.data?.postId);});
console.log('Vung publishing worker started');

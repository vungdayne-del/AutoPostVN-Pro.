import { GoogleGenerativeAI } from '@google/generative-ai';
import { pool } from './db.js';
import { decrypt } from './security.js';
async function apiKey() { const r=await pool.query("SELECT value FROM settings WHERE key='gemini_api_key'"); if(!r.rowCount) throw new Error('Chưa cấu hình Gemini API key'); return decrypt(r.rows[0].value); }
export async function generateContent(topic:string, instructions='') {
 const key=await apiKey(); const genAI=new GoogleGenerativeAI(key); const model=genAI.getGenerativeModel({model:'gemini-2.5-flash'});
 const prompt=`Bạn là biên tập viên Facebook Page. Viết nội dung tiếng Việt hữu ích, không bịa số liệu, không giả vờ đã xác minh nguồn. Chủ đề: ${topic}. Yêu cầu: ${instructions}. Trả về JSON hợp lệ với các trường title, body, hashtags (mảng), sources (mảng URL nguồn nếu người dùng cung cấp; nếu chưa nghiên cứu web thì để []).`;
 const result=await model.generateContent(prompt); const raw=result.response.text().replace(/^```json\s*/,'').replace(/```$/,'').trim();
 let parsed:any; try { parsed=JSON.parse(raw); } catch { throw new Error('Gemini trả về dữ liệu không phải JSON hợp lệ'); }
 await pool.query("INSERT INTO ai_usage(provider,estimated_usd,units) VALUES('gemini',0,1)");
 const budget=await pool.query("SELECT COALESCE(SUM(estimated_usd),0) AS total FROM ai_usage WHERE created_at >= date_trunc('day',now())"); const max=Number(process.env.DEFAULT_DAILY_AI_BUDGET_USD ?? 5); if(Number(budget.rows[0].total)>max) throw new Error('Đã chạm giới hạn ngân sách AI trong ngày');
 return parsed;
}
